using UnityEngine;

public class CameraTargetTag : MonoBehaviour
{
}