using UnityEngine;

public class CapsulePrimitiveTag : MonoBehaviour
{
}