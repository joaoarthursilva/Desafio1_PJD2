using UnityEngine;

public class CubePrimitiveTag : MonoBehaviour
{
}